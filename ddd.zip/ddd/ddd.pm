#!/opt/perl5.10.1/bin/perl
#
#  $Author: Jason Rowley $
#
#  $Id: ddd.pm Mon Jan 10 21:24 EST 2010 Jason Rowley $
#
#  $LastChangedRevision: 1.0RC1 $
#
#  Copyright (C) 2009,2010  Jason Rowley <jrowley _at_ synacknetworks _ com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###########################################################################
#
# Dynamic DDoS Detector (ddd) version 1.0 RC1
#
# This plugin provides early warning of DoS/DDoS attacks. It is loosely 
# based on the functionality of John Fraizer's newdosdetect module, but 
# has been rewritten from scratch, hense the new name
#
# Version 1.0 RC1 uses a MySQL database to use for dynamic exclusions. 
# This was added because Netflow sensors fed by taps continue to see an 
# ongoing attack and alert continuously, until the attacker gives up. 
#
# Once an attack is mitigated, simply add the IP Address into the
# database using the cli, or the included web interface.
# 
# TODO:
# Still need to write a front end to insert exclusions.
# Currently, they are inserted manually. Yuck!


package ddd;

use strict;		# no cheating

use Sys::Syslog;	# used for logging
use DBD::mysql;

# NFSen modules
use NfProfile;
use NfConf;
use Notification;

### database login info
my $dsn         = 'dbi:mysql:ddd:127.0.0.1:3306';
my $user        = 'dbuser';
my $pass        = 'dbpass';

# setup logging
Sys::Syslog::setlogsock('unix');
  
our %cmd_lookup = 
(
	'try'	=> \&RunProc,
);

# Identify ourselves as an NFSen 1.3.x plugin
our $VERSION	= 130;

my $EODATA 	= ".\n";

my ( $nfdump, $PROFILEDIR );

# Debug mode 
# 0 = false, 1 = true
my $DEBUG	= 0;

my $emails	= "";
# Specify the notification email(s).
if ($DEBUG > 0)
{
	$emails = "user\@example.com";
	print "Emails = $emails\n\n";
}
else
{
	$emails = "distro-list\@example.com";
}

# Init alert levels
my $alert	= 0;

#TODO: remove
# Set the alert files
# these are imported into the nfsen index page via a php include
# displays an annoying list of time windows for active alerts
my $alertfile	= "/tmp/alert.txt";
my $alerttext	= "/tmp/alert-text.txt";

# beginning of the subject line for alerts
my $subject	= "";
if ($DEBUG > 0)
{
	$subject	= '[DEBUG] DDoS Alert:';
}
else
{
	$subject	= "DDoS Early Warning:";
}

sub RunProc 
{
	my $socket		= shift;	# scalar
	my $opts		= shift;	# reference to a hash

	# error checking example
	if ( !exists $$opts{'colours'} ) 
	{
		Nfcomm::socket_send_error($socket, "Missing value");
		return;
	}

	# retrieve values passed by frontend
	# two scalars
	my $colour1		= $$opts{'colour1'};
	my $colour2		= $$opts{'colour2'};

	# one array as arrayref
	my $colours		= $$opts{'colours'};

	my @othercolours	= ( 'red', 'blue' );

	# Prepare answer
	my %args;
	$args{'string'}		= "Greetings from backend plugin. Got colour values: '$colour1' and '$colour2'";
	$args{'othercolours'}	= \@othercolours;

	Nfcomm::socket_send_ok($socket, \%args);
}

#
# Periodic data processing function
# input:	hash reference including the items:
#	'profile'		profile name
#	'profilegroup'		profile group
#	'timeslot' 		time of slot to process: Format yyyymmddHHMM e.g. 200503031200
sub run 
{
	my $dbh			= DBI->connect($dsn, $user, $pass) or die "Can't connect to the DB: $DBI::errstr\n";

	my $argref		= shift;
	my $profile		= $$argref{'profile'};
	my $profilegroup	= $$argref{'profilegroup'};
	my $timeslot		= $$argref{'timeslot'};

	syslog('debug', "ddd.pm run: Profilegroup: $profilegroup, Profile: $profile, Time: $timeslot");

	my %profileinfo		= NfProfile::ReadProfile($profile, $profilegroup);
	my $profilepath		= NfProfile::ProfilePath($profile, $profilegroup);
	my $all_sources		= join ':', keys %{$profileinfo{'channel'}};
	my $netflow_sources	= "$PROFILEDIR/$profilepath/$all_sources";

	syslog('debug', "ddd.pm args: '$netflow_sources'");

	# get filters and iterate through them
	my $filterlistqry 	= "SELECT id,filter_type,name,packetrate,flowratio_lt,flowratio_gt,filter FROM filters";
	my $filterlist		= $dbh->prepare($filterlistqry);

	$filterlist->execute();

	while (my $fresult = $filterlist->fetchrow_hashref())
	{
		my $FILTERID		= 0;
		my $FILTERTYPE		= 0;
		my $FILTERNAME		= "";
		my $FILTER		= "";
		my $PACKETRATE		= 0;
		my $FLOWRATIO_LT	= 0;
		my $FLOWRATIO_GT	= 0;
		my $EXCLUSIONS		= "";
		my $NF_FILTER		= "";

		$FILTERID 	= $fresult->{'id'};
		$FILTERTYPE	= $fresult->{'filter_type'};
		$FILTERNAME	= $fresult->{'name'};
		$FILTER		= $fresult->{'filter'};
		$FLOWRATIO_LT	= $fresult->{'flowratio_lt'};
		$FLOWRATIO_GT	= $fresult->{'flowratio_gt'};
		$PACKETRATE	= $fresult->{'packetrate'};

		syslog ('info', "ddd.pm -------------------------------------------------------------");

		$alert		= 0;
		my @output	= ();
		my @tail	= ();

		# get exclusions for filter
		my $dbh2	= DBI->connect($dsn, $user, $pass) or die "Can't connect to the DB: $DBI::errstr\n";
		my $esql	= "SELECT ipaddr FROM exclusions WHERE filter = $FILTERID";
		my $elist	= $dbh2->prepare($esql);

		$elist->execute();

		my $ei 		= 0;
		while (my $eresult = $elist->fetchrow_hashref())
		{
			if ($ei == 0)
			{
				$EXCLUSIONS 	.= "(NOT net $eresult->{'ipaddr'} ";
			}
			elsif ($ei > 0)
			{
				$EXCLUSIONS	.= " AND NOT net $eresult->{'ipaddr'}";
			}

			$ei++;
		}

		if ($ei > 0)
		{
			$EXCLUSIONS	.= ")";
		}

		$dbh2->disconnect();

		syslog ('info', "ddd.pm exclusions: $EXCLUSIONS");

		# now, lets build our NFSen filters

		if ($FILTERTYPE == 1)
		{
			if ($EXCLUSIONS eq "")
			{
				$NF_FILTER 	= "(packets > $PACKETRATE) AND $FILTER";
			}
			else
			{
				$NF_FILTER 	= "((packets > $PACKETRATE) AND $FILTER) AND $EXCLUSIONS";
			}
			@output	= `$nfdump -M $netflow_sources -r nfcapd.$timeslot '$NF_FILTER' -a -o extended`;
		}
		elsif ($FILTERTYPE == 2)
		{
			if ($EXCLUSIONS eq "")
			{
				$NF_FILTER 	= "$FILTER";
			}
			else
			{
				$NF_FILTER 	= "$FILTER AND $EXCLUSIONS";
			}
			@output = `$nfdump -M $netflow_sources -r nfcapd.$timeslot -n 200 -s record/flows -A dstip -o "fmt:%da %pkt %byt %fl %bps %pps %bpp" -l $PACKETRATE '$NF_FILTER'`;
		}
		elsif ($FILTERTYPE == 3)
		{
			if ($EXCLUSIONS eq "")
			{
				$NF_FILTER 	= "$FILTER";
			}
			else
			{
				$NF_FILTER 	= "$FILTER AND $EXCLUSIONS";
			}
			@output = `$nfdump -M $netflow_sources -r nfcapd.$timeslot -n 200 -s ip -l $PACKETRATE '$NF_FILTER'`; 
		}
		else
		{
			syslog('debug', "ddd.pm undefined filter_type value returned from database. Exiting...");
			return -123;
		}

		syslog('info', "ddd.pm run: Checking $FILTERNAME");
		syslog('info', "ddd.pm run: NF Filter: $NF_FILTER");

		if ($DEBUG > 0)
		{
			print "########################################\n";
			print "Starting check: $FILTERNAME\n";
			print "@output\n";
		}

		if ($FILTERTYPE == 1)
		{
			if ($output[-4] =~ /total flows: (\d+)/)
			{
				my $matched = $1;

				if ($matched > 0)
				{
					if ($DEBUG > 0)
					{
						print "Matched $output[-4]\n";
					}

					syslog('info', "ddd.pm run: $FILTERNAME: Matched $matched flows");

					$alert	= 1;
					notify("$subject $FILTERNAME : Profile $profile, Timeslot $timeslot", \@output, $emails );

					my $outstring = "";
					foreach my $item (@output) 
					{
						$outstring .= $item . "\n";
					}

					# log attack to database
					logAttackAlert($FILTERID, $FILTERNAME, $profile, $timeslot, $outstring);
				}
			}
		}
		elsif ($FILTERTYPE == 2)
		{
			if ($output[1] =~ /Aggregated flows (\d+)/)
			{
				my $matched = $1;

				if ($matched > 0)
				{
					my $lines = 3 + $matched;
					if ($lines > 203)
					{
						$lines = 203;
					}

					while ($lines > 3)
					{
						my $text	= $output[$lines];
						$text		=~ s/M//g;
						$text		=~ s/G//g;

						my ($IP, $packets, $bytes, $flows)	= split ' ', $text;

						my $ratio	= $packets / $flows;

						if (($FLOWRATIO_LT > 0) and ($FLOWRATIO_GT > 0))
						{
							if (($ratio < $FLOWRATIO_LT) or ($ratio > $FLOWRATIO_GT))
							{
								$alert	= 1;

								syslog('info', "ddd.pm run: $FILTERNAME: Exceeded ratio with: $ratio");

								notify("$subject $FILTERNAME : Profile $profile, Timeslot $timeslot", \@output, $emails );

								my $outstring = "";
								foreach my $item (@output) 
								{
									$outstring .= $item . "\n";
								}

								# log attack to database
								logAttackAlert($FILTERID, $FILTERNAME, $profile, $timeslot, $outstring);
							}
                                                }
						elsif (($FLOWRATIO_LT >= 0) and ($FLOWRATIO_GT == 0))
						{
							if ($ratio < $FLOWRATIO_LT)
							{
								$alert	= 1;

								syslog('info', "ddd.pm run: $FILTERNAME: Exceeded ratio with: $ratio");

								notify("$subject $FILTERNAME : Profile $profile, Timeslot $timeslot", \@output, $emails );

								my $outstring = "";
								foreach my $item (@output) 
								{
									$outstring .= $item . "\n";
								}


								# log attack to database
								logAttackAlert($FILTERID, $FILTERNAME, $profile, $timeslot, $outstring);
							}
						}
						elsif (($FLOWRATIO_LT == 0) and ($FLOWRATIO_GT > 0))
						{
							if ($ratio < $FLOWRATIO_GT)
							{
								$alert	= 1;

								syslog('info', "ddd.pm run: $FILTERNAME: Exceeded ratio with: $ratio");

								notify("$subject $FILTERNAME : Profile $profile, Timeslot $timeslot", \@output, $emails );

								my $outstring = "";
								foreach my $item (@output) 
								{
									$outstring .= $item . "\n";
								}

								# log attack to database
								logAttackAlert($FILTERID, $FILTERNAME, $profile, $timeslot, $outstring);
							}
						}

						$lines--;
					}
				}
				else
				{
					syslog('info', "ddd.pm run: No matching flows found for $FILTERNAME");
				}
			}
		}
		elsif ($FILTERTYPE == 3)
		{
			my @sorted	= ();
			my $matched	= 0;
			my $linenum	= 0;
			my $numlines	= 0;
			my $maxlines	= 0;

			$numlines = scalar(@output);
			if ($numlines > 8)
			{
				syslog('info', "ddd.pm run: Matched filter, checking ratios");

				push (@sorted, $output[0]);
				push (@sorted, $output[2]);

				### gets the summary lines
				if ($output[-4] =~ /Summary:/)
				{
					push (@tail, $output[-4]);
					push (@tail, $output[-3]);
					push (@tail, $output[-2]);
					push (@tail, $output[-1]);
				}

				### skip first 2 lines, start on 3rd
				$linenum = 2;

				### process everything, excluding the footer
				$maxlines = $numlines - 5;

				while ($linenum < $maxlines)
				{
					my $text	= $output[$linenum];
					$text		=~ s/\s+/ /g;
					$text		=~ s/M//g;
					$text		=~ s/G//g;
					$text		=~ s/\(.*?\)//g;

					my ($g1, $g2, $g3, $g4, $IP, $flows, $packets, $bytes) = split ' ', $text;
					my $ratio	= $packets / $flows;

					if (($ratio < $FLOWRATIO_LT) or ($ratio > $FLOWRATIO_GT))
					{
						syslog('info', "ddd.pm run: $FILTERNAME: Exceeded ratio with: $ratio");
						$alert			= 1;
						$output[$linenum]	=~ s/any/UDP/g;

						push (@sorted, $output[$linenum]);
						push (@sorted, "       Packets: Flows Ratio = $ratio:1\n\n");
					}

					$linenum++;
				}
			}

			if ($alert > 0)
			{
				push (@sorted, @tail);

				notify("$subject $FILTERNAME : Profile $profile, Timeslot $timeslot", \@sorted, $emails );

				my $outstring = "";
				foreach my $item (@sorted) 
				{
					$outstring .= $item . "\n";
				}

				# log attack to database
				logAttackAlert($FILTERID, $FILTERNAME, $profile, $timeslot, $outstring);
			}
		}
		else
		{
			syslog('err', "ddd.pm Unparsable output line '$output[-4]'");
		}

		syslog('info', "ddd.pm end: $FILTERNAME");
	}

	syslog ('info', "ddd.pm -------------------------------------------------------------");

	$dbh->disconnect();
}

sub logAttackAlert
{
	my $dbh3	= DBI->connect($dsn, $user, $pass) or die "Can't connect to the DB: $DBI::errstr\n";

	my ($fid, $fn, $p, $ts, $os) = @_;

	syslog('debug', "logsql: INSERT INTO alerts VALUES (NULL, $fid, '$p', '$ts', '$os')");

	$dbh3->do("INSERT INTO alerts VALUES (NULL, $fid, '$p', '$ts', '$os')");

	if ($dbh3->err())
	{
		die "$DBI::errstr\n";
	}

	$dbh3->disconnect();

	my $alertfile	= "/tmp/alert.txt";
	my $alerttext	= "/tmp/alert-text.txt";

	open (ALERT, ">>$alertfile");
	print ALERT "$fn: Profile $p, Timeslot $ts<br>\n";
	close (ALERT);

	system ("chmod 666 $alertfile");

	open (ALERTTEXT, ">>$alerttext");
	print ALERTTEXT "---------------------------------------------------------------------------\n";
	print ALERTTEXT "$fn, Timeslot $ts\n", $os, "\n\n";
	close (ALERTTEXT);
}

#
# Alert condition function.
# if defined it will be automatically listed as available plugin, when defining an alert.
# Called after flow filter is applied. Resulting flows stored in $alertflows file
# Should return 0 or 1 if condition is met or not
#
sub alert_condition 
{
	my $argref	= shift;
	my $alert	= $$argref{'alert'};
	my $alertflows	= $$argref{'alertfile'};
	my $timeslot	= $$argref{'timeslot'};

	syslog('info', "Alert condition function called: alert: $alert, alertfile: $alertflows, timeslot: $timeslot");

	return 1;
}

#
# Alert action function.
# if defined it will be automatically listed as available plugin, when defining an alert.
# Called when the trigger of an alert fires.
# Return value ignored
#
sub alert_action 
{
	my $argref	= shift;
	my $alert	= $$argref{'alert'};
	my $timeslot	= $$argref{'timeslot'};

	syslog('info', "Alert action function called: alert: $alert, timeslot: $timeslot");

	return 1;
}

#
# The Init function is called when the plugin is loaded. It's purpose is to give the plugin 
# the possibility to initialize itself. The plugin should return 1 for success or 0 for 
# failure. If the plugin fails to initialize, it's disabled and not used. Therefore, if
# you want to temporarily disable your plugin return 0 when Init is called.
#
sub Init 
{
	syslog("info", "ddd.pm: Starting");

	# Init some vars
	$nfdump		= "$NfConf::PREFIX/nfdump";
	$PROFILEDIR	= "$NfConf::PROFILEDATADIR";

	return 1;
}

#
# The Cleanup function is called, when nfsend terminates. It's purpose is to give the
# plugin the possibility to cleanup itself. It's return value is discard.
#
sub Cleanup 
{
	syslog("info", "ddd.pm Calling maid service for cleanup...");
}

1;
